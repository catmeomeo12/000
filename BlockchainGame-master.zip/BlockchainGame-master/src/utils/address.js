export const llgContractAddress = "0x0e04Ad5f9a40ddfe82ac533C9D5284Fb3C72BcAa";
export const llgRewardContractAddress = "0x9274011471a1Fac4fD5304fc1f8a536150057df7";
export const chainId = 0x61;